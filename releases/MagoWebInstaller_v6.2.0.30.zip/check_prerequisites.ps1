$genericFunctions = Join-Path -Path $PSScriptRoot -ChildPath "generic_functions.ps1"
. $genericFunctions

$isDotnetInstalled = IsDotnetInstalled
$isScoopInstalled = IsScoopInstalled

if ($isDotnetInstalled -eq $true -and $isScoopInstalled -eq $true) {
	exit 0
}

exit 1


 
