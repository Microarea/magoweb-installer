#-------------------------------------------------------------------------------------------------
function ExistFile([string] $fileFullPath)
{
	If ($fileFullPath -eq '') {	
		write-host non esiste
		return $false;
	}
	
	return Test-Path -Path $fileFullPath -PathType Leaf -ErrorAction SilentlyContinue
}

#-------------------------------------------------------------------------------------------------
function ExistBucket([string] $search)
{
	$buckets = scoop bucket list 
	foreach($bucket in $buckets)
	{	
		if ($bucket.Name -eq $search)
		{
			return $true
		}
	}		
	return $false
}

#-------------------------------------------------------------------------------------------------
function AddScoopShimPath() {
	
	$shortHomePath =(New-Object -ComObject Scripting.FileSystemObject).GetFolder("$home").ShortPath 
	$scoopUserPath =  $shortHomePath+ "\scoop\shims"
	$res = AddUserEnvPath $scoopUserPath
}

#-------------------------------------------------------------------------------------------------
function AddUserEnvPath([string] $path) {
	$actualPath = [Environment]::GetEnvironmentVariable("PATH", "User");
	
	$index = $actualPath.IndexOf($path)
	if ($index -lt 0)
	{
		write-host user path $path not found...adding now
		
		$actualPath = $path + [IO.Path]::PathSeparator + $actualPath 
		[Environment]::SetEnvironmentVariable("Path", $actualPath, "User" )
		return
	}
	write-host nothing to do
}

#-------------------------------------------------------------------------------------------------
function InstallScoopIfNeeded()
{
	$scoopMainFile = Get-Command -ErrorAction SilentlyContinue scoop
	
	# $scoopMainFile is null or empty if previuos command produce error
	If (![string]::IsNullOrWhitespace($scoopMainFile)) {		
		Write-Host scoop already installed -ForegroundColor Green
		return 
		
	}
	Write-Host installing scoop
	iex "& {$(irm get.scoop.sh)} -RunAsAdmin"

	AddScoopShimPath
}

#-------------------------------------------------------------------------------------------------
function CheckAndInstallWithScoop([string] $processName)
{
	Write-Host checking $processName installation...
	
	$processFile = scoop which $processName
	$alreadyExistFile = ExistFile $processFile 
	If ($alreadyExistFile -eq $true) {	
		Write-Host $processName already installed -ForegroundColor Green
		return $processFile
	}
	
	Write-Host  $processName not found, installing...
	$installResult = scoop install -g $processName
	$processFile = scoop which $processName
	
	$alreadyExistFile = ExistFile $processFile 
	If ($alreadyExistFile -eq $false) {	
		Write-Host $processName installation failed -ForegroundColor Red
		return $processFile
	}

	return $processFile
}


Write-host Installing prerequisites... -ForegroundColor Green
Write-host please wait... -ForegroundColor Green

InstallScoopIfNeeded

CheckAndInstallWithScoop "git"
CheckAndInstallWithScoop "zstd"

$existBucket = ExistBucket "extras" 
if ($existBucket -eq $false)
{
	scoop bucket add extras
}

Write-host Installing dotnet if needed... -ForegroundColor Green

Invoke-WebRequest 'https://dotnet.microsoft.com/download/dotnet/scripts/v1/dotnet-install.ps1' -OutFile 'dotnet-install.ps1';
./dotnet-install.ps1 -InstallDir 'C:\Program Files\dotnet' -Version '8.0.101' 
erase ./dotnet-install.ps1

Write-Host prerequisites successfully installed
# SIG # Begin signature block
# MIIpDQYJKoZIhvcNAQcCoIIo/jCCKPoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCArMt3SGB96Wo0f
# BPyJqnpbv+JSTcJtA9dAks/PiTbG/qCCDhAwggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggdYMIIFQKADAgECAhALY7FEOp3D0E4VNYGo0wZaMA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjUwMTA3MDAwMDAwWhcNMjgwMTA2
# MjM1OTU5WjBgMQswCQYDVQQGEwJJVDESMBAGA1UECBMJTG9tYmFyZGlhMQ0wCwYD
# VQQHEwRMb2RpMRYwFAYDVQQKEw1adWNjaGV0dGkgU3BBMRYwFAYDVQQDEw1adWNj
# aGV0dGkgU3BBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA3TaQlQcB
# gxfabFLVq5czkhW1gTdCfXaoUnx2VRkKnlDbeA/mktrWbKwKBQCGLboy734CoJz/
# 7aQys0sQJ25CLh7Btcu8OKpTgyV1oO4sIg8z2XYOA258LFYW0dlDdkBpU6nOsaSI
# Ubefsa+2WLOA9V1BI7P54GbSVPbcam9AsM4bI6pH+PxxPHIR24LLXOxmLx6UMiP3
# QILtPlasERpDL/l19mnpAr8EaHavGBHLYgZRtqxS5fG6o4fG+Dkd9l2Mxveb3OGX
# LesJquS3h9NRfVwEEImjTUMRcHIJwNxz1hm9d8yxWUc5M2jhiN3FMsvHRgi6/skI
# EAvZuNX6obNG3Sm/PR3+M+KNVEa0BS0zHUGzEjbw6KzS4fKLFWtnkdYwE5g3A0nr
# kX8YURP5YoySbkV07qJ/cu+pgcfmU5oCk8bIUYFK3cVCuRGsqbCj1h8jjriXSXei
# fgx47CvTHA2XozCuYnUeoZQkmc+nhF7LqrbRdRtJVXdQpucb5N/QoDW0z9XmIY33
# fLWnPH86yK9MP3QP95B03VR4vgW0zzHzeYOC8pU/eKLdMjlgE4NXmI7p1a+cwjQX
# A6H9yJ6N0v4g/c1fI1sjHCrihZ7V9+JgojZSbBCST/PsWp+IrZSK5xvNZNfT1NgV
# +u5l3SKaLcxY+lzzypd/3YTHoGdI3I74JakCAwEAAaOCAgMwggH/MB8GA1UdIwQY
# MBaAFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB0GA1UdDgQWBBQEQbu7d7WI8BgYORO6
# AXiqJbpJuTA+BgNVHSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIBFhtodHRw
# Oi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQM
# MAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9jcmwzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5NlNI
# QTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0Ex
# LmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3Nw
# LmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0
# MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEAP790s7hk
# /lROJkN/2hncbK45xQUhaE7snFu5NPI76RP2moIW7v6xEtc2cTHOAU/Bh5NqWtOW
# v1hKVNX2AbTPiMKq0ghVA3gE8LC6mePQgCDNNWM0VFWlAwFFr+mXXWJeWEQIdKYD
# AHWwR0KyvseKy5FQWQXo46RHClsLhWn3VTkZOkz9ErEj5akP7jLfDBjizVx/6B5/
# Nf8FJZwpy+EsJY4hCgsLtcgWrESKPRZnhccDlmG9IFPm7DUktf7By4U+IZJDQVFh
# rP0AwB7HxiP/JCds1IkFBUA05hC2iD0Ybg11UVSGwI8w+RfRMPCCX6WPUMOiT8Vq
# q4+JGM7grPv9rTxhilH14WxF4UJB4osO1ySVuPl9IXp/QJjbs81TiQKMaxYnCNC2
# wOcqibyzqNUkGWhpX6edZ18fRAXU6AxRu7GAQ4dDYP6sNqa2u606yTFMG8IEg6Fw
# 5X7bot90i/uez57mZfo52VQF1dmojsAgvwuGczgHfiHr5BWTDo+QijfNbE9vEOTC
# YVWTco7R5Hoxkg6O4b8lhs5xMfZA0MRXImHxQ+rwMduiJbBN/abvVxUy0jXhwpk0
# 5OyRm1OwoFnHX4atFv4iJcBm3IhkqFymhS6pJA4gVv6PnhPT0AqcDisGXLnYbvTa
# VWWP9NlY/Mm6qNlFK7vczdsxO3tftKXFfAwxghpTMIIaTwIBATB9MGkxCzAJBgNV
# BAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNl
# cnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBD
# QTECEAtjsUQ6ncPQThU1gajTBlowDQYJYIZIAWUDBAIBBQCgfDAQBgorBgEEAYI3
# AgEMMQIwADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgEL
# MQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgRnwOh/7M3FBJZliyfe7f
# ahH8C1N8qaN/f9fDtSS9hccwDQYJKoZIhvcNAQEBBQAEggIATatdZuRgnmjfOs01
# xqof12mtVI6+PHNiVPO+ZPhFmQ/xBhtfePzqgJsYBk6mHjto5ic6Qek6c05gQh/e
# t4vM9YSrVlMH7EXWJ/wzjwrkvUyD40zunVnIi5XBh16VvgOnW/+grB3y77AVzo/u
# 2d5tE1Pzwor4MMOeaw2BMl0bPXz5IadVKUm0j87jCT3jkijCYG59VlKS0LfRIPWw
# WyhiJUDNxakR0+PjKu0XLyk06TAlxccXVgM10Jjed85dooYutWG8NytHXx8pwSN5
# PumOUHQdl6CC4Wt1OQQzxR6hcOB99tbuxogI5vAv6PHLtpMh7lV8HDpZ+oSt/i6b
# DP5491bmVDpPdb8n/42KJeUDQL55slrqPmLL+yQ0E/Urkx9K/I71ym2DbUDFHY1I
# mxD+onCNNQQQEThrJ8KEbFRCuAyJk6FcOzM1v8WuFGR3271xCw1Svxedt6+lXlA6
# gxetA3jbSo5SKnZDfLvaagZ8aFOGpz+o2An7R6KFFdtKEON4y73m9EsyRilmqZ0a
# oZlkFmQ5wlgZSblH2A/C0kLfVQPK3hH+CRkkCQntSRw0pFcfPaj/LqFoYmh1mujI
# wTWgO/1bBJtnLbTGYCSLwSyOKShGf2425JULZGCax4EXsc1DvN+vzfqxmqbIs/Wt
# KX3h1ABz/qkGr0nXx9ZunshNvqShghcpMIIXJQYKKwYBBAGCNwMDATGCFxUwghcR
# BgkqhkiG9w0BBwKgghcCMIIW/gIBAzEPMA0GCWCGSAFlAwQCAQUAMGcGCyqGSIb3
# DQEJEAEEoFgEVjBUAgEBBglghkgBhv1sBwEwITAJBgUrDgMCGgUABBSNqWBcem8v
# AA4Bw/JVYyxZGYuaIgIQC3YcMDE8GvJLRSHhVthf9RgPMjAyNTAzMTcwODEyMzJa
# oIITAzCCBrwwggSkoAMCAQICEAuuZrxaun+Vh8b56QTjMwQwDQYJKoZIhvcNAQEL
# BQAwYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYD
# VQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVTdGFt
# cGluZyBDQTAeFw0yNDA5MjYwMDAwMDBaFw0zNTExMjUyMzU5NTlaMEIxCzAJBgNV
# BAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDEgMB4GA1UEAxMXRGlnaUNlcnQgVGlt
# ZXN0YW1wIDIwMjQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC+anOf
# 9pUhq5Ywultt5lmjtej9kR8YxIg7apnjpcH9CjAgQxK+CMR0Rne/i+utMeV5bUlY
# YSuuM4vQngvQepVHVzNLO9RDnEXvPghCaft0djvKKO+hDu6ObS7rJcXa/UKvNmin
# KQPTv/1+kBPgHGlP28mgmoCw/xi6FG9+Un1h4eN6zh926SxMe6We2r1Z6VFZj75M
# U/HNmtsgtFjKfITLutLWUdAoWle+jYZ49+wxGE1/UXjWfISDmHuI5e/6+NfQrxGF
# SKx+rDdNMsePW6FLrphfYtk/FLihp/feun0eV+pIF496OVh4R1TvjQYpAztJpVIf
# dNsEvxHofBf1BWkadc+Up0Th8EifkEEWdX4rA/FE1Q0rqViTbLVZIqi6viEk3RIy
# Sho1XyHLIAOJfXG5PEppc3XYeBH7xa6VTZ3rOHNeiYnY+V4j1XbJ+Z9dI8ZhqcaD
# HOoj5KGg4YuiYx3eYm33aebsyF6eD9MF5IDbPgjvwmnAalNEeJPvIeoGJXaeBQjI
# K13SlnzODdLtuThALhGtyconcVuPI8AaiCaiJnfdzUcb3dWnqUnjXkRFwLtsVAxF
# vGqsxUA2Jq/WTjbnNjIUzIs3ITVC6VBKAOlb2u29Vwgfta8b2ypi6n2PzP0nVeps
# Fk8nlcuWfyZLzBaZ0MucEdeBiXL+nUOGhCjl+QIDAQABo4IBizCCAYcwDgYDVR0P
# AQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgw
# IAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaAFLoW
# 2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBSfVywDdw4oFZBmpWNe7k+SH3ag
# WzBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGln
# aUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3JsMIGQ
# BggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3J0
# MA0GCSqGSIb3DQEBCwUAA4ICAQA9rR4fdplb4ziEEkfZQ5H2EdubTggd0ShPz9Pc
# e4FLJl6reNKLkZd5Y/vEIqFWKt4oKcKz7wZmXa5VgW9B76k9NJxUl4JlKwyjUkKh
# k3aYx7D8vi2mpU1tKlY71AYXB8wTLrQeh83pXnWwwsxc1Mt+FWqz57yFq6laICtK
# jPICYYf/qgxACHTvypGHrC8k1TqCeHk6u4I/VBQC9VK7iSpU5wlWjNlHlFFv/M93
# 748YTeoXU/fFa9hWJQkuzG2+B7+bMDvmgF8VlJt1qQcl7YFUMYgZU1WM6nyw23vT
# 6QSgwX5Pq2m0xQ2V6FJHu8z4LXe/371k5QrN9FQBhLLISZi2yemW0P8ZZfx4zvSW
# zVXpAb9k4Hpvpi6bUe8iK6WonUSV6yPlMwerwJZP/Gtbu3CKldMnn+LmmRTkTXpF
# IEB06nXZrDwhCGED+8RsWQSIXZpuG4WLFQOhtloDRWGoCwwc6ZpPddOFkM2LlTbM
# cqFSzm4cd0boGhBq7vkqI1uHRz6Fq1IX7TaRQuR+0BGOzISkcqwXu7nMpFu3mgrl
# gbAW+BzikRVQ3K2YHcGkiKjA4gi4OA/kz1YCsdhIBHXqBzR0/Zd2QwQ/l4Gxftt/
# 8wY3grcc/nS//TVkej9nmUYu83BDtccHHXKibMs/yXHhDXNkoPIdynhVAku7aRZO
# wqw6pDCCBq4wggSWoAMCAQICEAc2N7ckVHzYR6z9KGYqXlswDQYJKoZIhvcNAQEL
# BQAwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UE
# CxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBS
# b290IEc0MB4XDTIyMDMyMzAwMDAwMFoXDTM3MDMyMjIzNTk1OVowYzELMAkGA1UE
# BhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJEaWdpQ2Vy
# dCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVTdGFtcGluZyBDQTCCAiIw
# DQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMaGNQZJs8E9cklRVcclA8TykTep
# l1Gh1tKD0Z5Mom2gsMyD+Vr2EaFEFUJfpIjzaPp985yJC3+dH54PMx9QEwsmc5Zt
# +FeoAn39Q7SE2hHxc7Gz7iuAhIoiGN/r2j3EF3+rGSs+QtxnjupRPfDWVtTnKC3r
# 07G1decfBmWNlCnT2exp39mQh0YAe9tEQYncfGpXevA3eZ9drMvohGS0UvJ2R/dh
# gxndX7RUCyFobjchu0CsX7LeSn3O9TkSZ+8OpWNs5KbFHc02DVzV5huowWR0QKfA
# csW6Th+xtVhNef7Xj3OTrCw54qVI1vCwMROpVymWJy71h6aPTnYVVSZwmCZ/oBpH
# IEPjQ2OAe3VuJyWQmDo4EbP29p7mO1vsgd4iFNmCKseSv6De4z6ic/rnH1pslPJS
# lRErWHRAKKtzQ87fSqEcazjFKfPKqpZzQmiftkaznTqj1QPgv/CiPMpC3BhIfxQ0
# z9JMq++bPf4OuGQq+nUoJEHtQr8FnGZJUlD0UfM2SU2LINIsVzV5K6jzRWC8I41Y
# 99xh3pP+OcD5sjClTNfpmEpYPtMDiP6zj9NeS3YSUZPJjAw7W4oiqMEmCPkUEBID
# fV8ju2TjY+Cm4T72wnSyPx4JduyrXUZ14mCjWAkBKAAOhFTuzuldyF4wEr1GnrXT
# drnSDmuZDNIztM2xAgMBAAGjggFdMIIBWTASBgNVHRMBAf8ECDAGAQH/AgEAMB0G
# A1UdDgQWBBS6FtltTYUvcyl2mi91jGogj57IbzAfBgNVHSMEGDAWgBTs1+OC0nFd
# ZEzfLmc/57qYrhwPTzAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUH
# AwgwdwYIKwYBBQUHAQEEazBpMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQQYIKwYBBQUHMAKGNWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3J0MEMGA1UdHwQ8MDowOKA2oDSGMmh0
# dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3Js
# MCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsF
# AAOCAgEAfVmOwJO2b5ipRCIBfmbW2CFC4bAYLhBNE88wU86/GPvHUF3iSyn7cIoN
# qilp/GnBzx0H6T5gyNgL5Vxb122H+oQgJTQxZ822EpZvxFBMYh0MCIKoFr2pVs8V
# c40BIiXOlWk/R3f7cnQU1/+rT4osequFzUNf7WC2qk+RZp4snuCKrOX9jLxkJods
# kr2dfNBwCnzvqLx1T7pa96kQsl3p/yhUifDVinF2ZdrM8HKjI/rAJ4JErpknG6sk
# HibBt94q6/aesXmZgaNWhqsKRcnfxI2g55j7+6adcq/Ex8HBanHZxhOACcS2n82H
# hyS7T6NJuXdmkfFynOlLAlKnN36TU6w7HQhJD5TNOXrd/yVjmScsPT9rp/Fmw0HN
# T7ZAmyEhQNC3EyTN3B14OuSereU0cZLXJmvkOHOrpgFPvT87eK1MrfvElXvtCl8z
# OYdBeHo46Zzh3SP9HSjTx/no8Zhf+yvYfvJGnXUsHicsJttvFXseGYs2uJPU5vIX
# mVnKcPA3v5gA3yAWTyf7YGcWoWa63VXAOimGsJigK+2VQbc61RWYMbRiCQ8KvYHZ
# E/6/pNHzV9m8BPqC3jLfBInwAM1dwvnQI38AC+R2AibZ8GV2QqYphwlHK+Z/GqSF
# D/yYlvZVVCsfgPrA8g4r5db7qS9EFUrnEw4d2zc4GqEr9u3WfPwwggWNMIIEdaAD
# AgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYT
# AlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2Vy
# dC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0y
# MjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYD
# VQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAf
# BgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4Smn
# PVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6f
# qVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O
# 7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZ
# Vu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4F
# fYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLm
# qaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMre
# Sx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/ch
# srIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+U
# DCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xM
# dT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUb
# AgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFd
# ZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAO
# BgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRw
# Oi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRz
# LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0f
# BD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNz
# dXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEM
# BQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLt
# pIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouy
# XtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jS
# TEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAc
# AgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2
# h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQxggN2MIIDcgIBATB3MGMxCzAJBgNVBAYT
# AlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQg
# VHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0ECEAuuZrxa
# un+Vh8b56QTjMwQwDQYJYIZIAWUDBAIBBQCggdEwGgYJKoZIhvcNAQkDMQ0GCyqG
# SIb3DQEJEAEEMBwGCSqGSIb3DQEJBTEPFw0yNTAzMTcwODEyMzJaMCsGCyqGSIb3
# DQEJEAIMMRwwGjAYMBYEFNvThe5i29I+e+T2cUhQhyTVhltFMC8GCSqGSIb3DQEJ
# BDEiBCApYKTgy/a9XTwfI9Z1kdDu7S61qjMPdMJ24qiwJ2kLnDA3BgsqhkiG9w0B
# CRACLzEoMCYwJDAiBCB2dp+o8mMvH0MLOiMwrtZWdf7Xc9sF1mW5BZOYQ4+a2zAN
# BgkqhkiG9w0BAQEFAASCAgBoO1rxgCgirSJAXf/6lEZThc1T04iFOh3v/vtweOIq
# kKq+mbKhSX8Ogesxb5gwv7PUYlrtV6Cz3bhUOU94rBC6/Y8O/VoxhkvyrP8gYr4F
# NIckqqgViODoPCL9RedeF8WqeHGrK02wztiHYd1um8DftvT8sB/6FLUqnXlXwY2X
# UYamaHVijWk1oJfscUE/ZDavAJ7nt5RRB+MLGpTrTqf5PG46AAh3bqYTVTp42NBt
# n5pwsb0O/yfZ+vmpfNp53Ika/uXvIXs6MzlZd39JwcEd21hNGy/uwwPunnGDdgzj
# XN2tmg9WZnZmvHLsGfwwknTLuxSIs7nQAMjyZLEaaY2Vl5psGvmO/CFvlUQfwjwk
# 4jxerMwLaURH0aN95GyACOn8diAgI9uaOjumRaG9isRrpj9/Gh3b8IndoXRnTXJj
# uNJLggsPntmlHsq6IaY4f+gEu9GfvhB+N4Xo7qoATMfKbLvrlULQRXuXLYhfKE2s
# xWnrKFmSdPdPhjKZlYcN9MqcgjK3EgK7QU1RMdZFGmVDeLC9dO2YSWr0LjwMumTG
# F7dNohBkGWl7FZa4hBcqc1X71gja9i1tpgSq+fDz7hwsCQ31JIm6xsdTt7P2nRa0
# gppEsN9Fei0MGooKPgk9CxlOKTKdBM8Lu3R/5bV/pvKiHRAD5GzZXZ6dqSuTaAtx
# Uw==
# SIG # End signature block
