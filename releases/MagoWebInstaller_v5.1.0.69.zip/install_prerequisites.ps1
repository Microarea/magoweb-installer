
#-------------------------------------------------------------------------------------------------
function ExistFile([string] $fileFullPath)
{
	If ($fileFullPath -eq '') {	
		write-host non esiste
		return $false;
	}
	
	return Test-Path -Path $fileFullPath -PathType Leaf -ErrorAction SilentlyContinue
}

#-------------------------------------------------------------------------------------------------
function AddScoopShimPath() {
	
	$shortHomePath =(New-Object -ComObject Scripting.FileSystemObject).GetFolder("$home").ShortPath 
	$scoopUserPath =  $shortHomePath+ "\scoop\shims"
	$res = AddUserEnvPath $scoopUserPath
}

#-------------------------------------------------------------------------------------------------
function AddUserEnvPath([string] $path) {
	$actualPath = [Environment]::GetEnvironmentVariable("PATH", "User");
	
	$index = $actualPath.IndexOf($path)
	if ($index -lt 0)
	{
		write-host user path $path not found...adding now
		
		$actualPath = $path + [IO.Path]::PathSeparator + $actualPath 
		[Environment]::SetEnvironmentVariable("Path", $actualPath, "User" )
		return
	}
	write-host nothing to do
}

#-------------------------------------------------------------------------------------------------
function InstallScoopIfNeeded()
{
	$scoopMainFile = Get-Command -ErrorAction SilentlyContinue scoop
	
	# $scoopMainFile is null or empty if previuos command produce error
	If (![string]::IsNullOrWhitespace($scoopMainFile)) {		
		Write-Host scoop already installed -ForegroundColor Green
		return 
		
	}
	Write-Host installing scoop
	iex "& {$(irm get.scoop.sh)} -RunAsAdmin"

	AddScoopShimPath
}


#-------------------------------------------------------------------------------------------------
function InstallDotnet()
{
	Write-host Installing dotnet if needed...

	Invoke-WebRequest 'https://dotnet.microsoft.com/download/dotnet/scripts/v1/dotnet-install.ps1' -OutFile 'dotnet-install.ps1'; 
	./dotnet-install.ps1 -InstallDir 'C:\Program Files\dotnet' -Version '8.0.407'  
	erase ./dotnet-install.ps1 
}

Write-host Installing prerequisites, please wait...
 
InstallScoopIfNeeded 
 
InstallDotnet
 
Write-Host prerequisites successfully installed  -ForegroundColor Green 